<html>
<head>
   
</head>
<style>
 
 
</style>
 
<h1> Laravel  hasManyThrough Example </h1>
 
<h3> All Orders for India Shop </h3>
 
@foreach ($shopOrders as $order)
<li> 
 
    {{ $order->order_name }}  
 
</li>
@endforeach

<h3> All Orders for USA Shop </h3>

@foreach ($shopOrdersTwo as $order)
<li> 
 
    {{ $order->order_name }}  
 
</li>
@endforeach

<h3> All Orders for UK Shop </h3>

@foreach ($shopOrdersThree as $order)
<li> 
 
    {{ $order->order_name }}  
 
</li>
@endforeach


</html>