<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shop extends Model
{
    //
    public function orders()
    {
        return $this->hasManyThrough(
            Order::class,
            Product::class,
            'shop_id', // Foreign key on products table...
            'product_id', // Foreign key on orders table...
            'id', // Local key on countries table...
            'id' // Local key on users table...
        );
    }
}
