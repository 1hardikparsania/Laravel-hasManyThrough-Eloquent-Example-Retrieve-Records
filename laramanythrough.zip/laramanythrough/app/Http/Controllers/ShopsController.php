<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Shop;
use App\Order;

class ShopsController extends Controller
{
    //
    public function shopOrder()
    {
 
        $shops = Shop::find(1);	
        $shopOrders = $shops->orders;

        $shops = Shop::find(2);	
        $shopOrdersTwo = $shops->orders;

        $shops = Shop::find(3);	
        $shopOrdersThree = $shops->orders;

        //dd($shops->orders);
     
        return view('index',compact('shopOrders','shopOrdersTwo','shopOrdersThree'));
       
    }
}
