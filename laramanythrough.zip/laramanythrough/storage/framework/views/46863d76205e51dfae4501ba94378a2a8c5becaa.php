<html>
<head>
   
</head>
<style>
 
 
</style>
 
<h1> Laravel  hasManyThrough Example </h1>
 
<h3> All Orders for India Shop </h3>
 
<?php $__currentLoopData = $shopOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($order->order_name); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h3> All Orders for USA Shop </h3>

<?php $__currentLoopData = $shopOrdersTwo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($order->order_name); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h3> All Orders for UK Shop </h3>

<?php $__currentLoopData = $shopOrdersThree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($order->order_name); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</html><?php /**PATH /Users/hardikparsania_mac/Desktop/web_demonuts/laramanythrough/laramanythrough/resources/views/index.blade.php ENDPATH**/ ?>